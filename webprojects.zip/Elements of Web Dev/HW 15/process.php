<?php
$host = 'spring-2024.cs.utexas.edu';  
$dbUser = 'cs329e_bulko_terryzm';     
$dbPassword = 'mean5wrist7Grin'; 
$dbName = 'cs329e_bulko_terryzm'; 

$conn = new mysqli($host, $dbUser, $dbPassword, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT password FROM passwords WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if ($row['password'] == $password) {
        echo "User and password confirmed";
    } else {
        $updateSql = "UPDATE passwords SET password = ? WHERE username = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("ss", $password, $username);
        $updateStmt->execute();
        echo "Password changed";
    }
} else {
    $insertSql = "INSERT INTO passwords (username, password) VALUES (?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param("ss", $username, $password);
    $insertStmt->execute();
    echo "New user registered";
}

$stmt->close();
$conn->close();
?>
