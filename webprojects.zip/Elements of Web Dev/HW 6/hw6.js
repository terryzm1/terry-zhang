const principleAmountInput = document.querySelector('.p');
const annualInterestRateInput = document.querySelector('.r');
const monthsInput = document.querySelector('.n');

const monthlyPay = document.querySelector('.monthlypay .value');
const totalAmount = document.querySelector('.sumpay .value');
const interestAmount = document.querySelector('.suminterest .value');

const calculateBtn = document.querySelector('.calculate');
const clearBtn = document.querySelector('.clear');

let principleAmount = parseFloat(principleAmountInput.value);
let annualInterestRate = parseFloat(annualInterestRateInput.value);
let months = parseInt(monthsInput.value);

interestRate = annualInterestRate / 12;

const calculateR = () => {
    let R = principleAmount * (interestRate/(1 - (1 / (1 + interestRate) ** months)));
    return R;
};

const updateData = (R) => {
    monthlyPay.innerHTML = R.toFixed(2);

    let total = R * months;
    totalAmount.innerHTML = total.toFixed(2);

    inter = total - principleAmount;
    interestAmount.innerHTML = inter.toFixed(2);
};

const init = () => {
    let R = calculateR();
    updateData(R);
};

init();

const refresh = () => {
    principleAmount = parseFloat(principleAmountInput.value);
    annualInterestRate = parseFloat(annualInterestRateInput.value);
    months = parseInt(monthsInput.value);
    interestRate = annualInterestRate / 12;
}

calculateBtn.addEventListener("click", () => {
    refresh();
    let R = calculateR();
    updateData(R);
});

clearBtn.addEventListener("click", () => {
    document.getElementById('calculator').reset();
});