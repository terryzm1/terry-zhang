<?php
$host = 'spring-2024.cs.utexas.edu';  
$dbUser = 'cs329e_bulko_terryzm';     
$dbPassword = 'mean5wrist7Grin'; 
$dbName = 'cs329e_bulko_terryzm';  

$conn = new mysqli($host, $dbUser, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
