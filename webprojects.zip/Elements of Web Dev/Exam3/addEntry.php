<?php
session_start();
require 'db.php'; 

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    echo "unauthorized";
    exit;
}

$name = $_POST['name'] ?? '';
$items = $_POST['items'] ?? '';

$stmt = $conn->prepare("INSERT INTO dinner (name, items) VALUES (?, ?)");
$stmt->bind_param("ss", $name, $items);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "failure";
}

$stmt->close();
?>