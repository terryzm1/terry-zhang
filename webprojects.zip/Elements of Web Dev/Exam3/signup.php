<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Potluck Signup</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; }
        table, th, td { border: 1px solid black; border-collapse: collapse; padding: 10px; }
        th { background-color: #f0f0f0; }
        input, button { margin-top: 10px; }
    </style>
</head>
<body>
    <h2>Potluck Signup</h2>
    <form id="signupForm">
        Name: <input type="text" name="name" maxlength="20" required><br>
        Item to bring: <input type="text" name="items" maxlength="50" required><br>
        <button type="button" id="submitButton">Submit</button>
    </form>

    <table id="entriesTable">
        <thead>
            <tr><th>Name</th><th>Item to Bring</th></tr>
        </thead>
        <tbody></tbody>
    </table>

    <script>
        $(document).ready(function() {
            $('#submitButton').click(function() {
                addEntry();
            });
            fetchEntries();
        });

        function addEntry() {
            $.ajax({
                url: 'addEntry.php',
                type: 'POST',
                data: $('#signupForm').serialize(),
                success: function(data) {
                    console.log('Response:', data); 
                    if (data.trim() === 'success') {  
                        fetchEntries(); 
                        $('#signupForm')[0].reset(); 
                    } else {
                        alert('Error adding entry: ' + data);
                    }
                },
                error: function(xhr, status, error) {
                    alert('Error adding entry: ' + error);
                }
            });
        }


        function fetchEntries() {
            $.ajax({
                url: 'getEntries.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    const tableBody = $('#entriesTable tbody');
                    tableBody.empty(); 
                    data.forEach(function(entry) {
                        tableBody.append(`<tr><td>${entry.name}</td><td>${entry.items}</td></tr>`);
                    });
                },
                error: function(xhr, status, error) {
                    alert('Failed to fetch entries: ' + error);
                }
            });
        }
    </script>
</body>
</html>
