<?php
session_start();
require 'db.php'; 

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    echo "unauthorized";
    exit;
}

$result = $conn->query("SELECT name, items FROM dinner");
$entries = [];

while ($row = $result->fetch_assoc()) {
    $entries[] = $row;
}

echo json_encode($entries);
?>