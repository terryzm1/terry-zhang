<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $isValid = false;
    $accounts = file('login.txt', FILE_IGNORE_NEW_LINES);
    foreach ($accounts as $account) {
        list($storedUser, $storedPass) = explode(':', $account);
        if ($username === $storedUser && $password === $storedPass) {
            $isValid = true;
            break;
        }
    }

    if ($isValid) {
        $_SESSION['user'] = $username;
        header('Location: signup.php');
        exit();
    } else {
        $message = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Potluck Login</title>
    <meta name="description" content="Potluck Login">
    <meta name="author" content="Tianyu Zhang">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; }
        form { background: #f0f0f0; padding: 20px; border-radius: 5px; }
        input { margin-bottom: 10px; }
        button { padding: 10px 20px; }
    </style>
</head>
<body>
    <?php if (!empty($message)) echo "<p>$message</p>"; ?>
    <form id="loginForm" method="post">
        <h2>Login</h2>
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>

</body>
</html>
