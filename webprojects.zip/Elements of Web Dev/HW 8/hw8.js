var images = ["agra_fort.jpg", "ajanta_ellora.jpeg", "akshardham_temple.jpg", "gateway_of_india.jpg", "hawa_mahal.jpeg",
"mehrangarh_fort.jpg", "mysore_palace.jpeg", "qutub_minar.jpg", "sun_temple.jpg", "taj_mahal.jpeg", "victoria_memorial.jpg"];

var currentIndex = 0;

var timer;

function start() {
    timer = setInterval(nextImage, 3000); 
}

function end() {
    clearInterval(timer);
}

function nextImage() {
    currentIndex = (currentIndex + 1) % images.length;
    document.getElementById("image").src = images[currentIndex];
}

document.getElementById("startBtn").addEventListener("click", start);
document.getElementById("stopBtn").addEventListener("click", end);

start();
