let currentPlayer = "X";
let xWins = 0;
let oWins = 0;

function makeMove(button) {
    if (button.textContent === "") {
        button.textContent = currentPlayer;
        if (checkWin()) {
            alert(`${currentPlayer} has won!`);
            updateScoreboard();
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
        }
    }
}

function checkWin() {
    const buttons = document.querySelectorAll(".game-button");
    const winConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8], 
        [0, 4, 8], [2, 4, 6]
    ];
    for (let condition of winConditions) {
        if (buttons[condition[0]].textContent === currentPlayer &&
            buttons[condition[1]].textContent === currentPlayer &&
            buttons[condition[2]].textContent === currentPlayer) {
            return true;
        }
    }
    return false;
}

function updateScoreboard() {
    if (currentPlayer === "X") {
        xWins++;
        document.getElementById("x-wins").textContent = xWins;
    } else {
        oWins++;
        document.getElementById("o-wins").textContent = oWins;
    }
}

function resetGame() {
    const buttons = document.querySelectorAll(".game-button");
    buttons.forEach(button => {
        button.textContent = "";
    });
    currentPlayer = "X";
}

window.onload = resetGame();
