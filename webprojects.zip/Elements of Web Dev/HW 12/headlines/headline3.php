<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Israel's defense minister speaks to US counterpart about Iran's attack</title>
</head>
<body>
    <h1>Israel's defense minister speaks to US counterpart about Iran's attack</h1>
    <p>Israeli Defense Minister Yoav Gallant spoke to US Secretary of Defense Lloyd Austin on Sunday to provide a brief on the “preliminary conclusions” of the Israel military's “defensive operations” after Iran’s attack.</p>
</body>
</html>
