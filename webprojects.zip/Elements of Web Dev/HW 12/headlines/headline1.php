<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Palestinian girl shot in mother's arms as they attempted to return to home in northern Gaza</title>
</head>
<body>
    <h1>Palestinian girl shot in mother's arms as they attempted to return to home in northern Gaza</h1>
    <p>As chaos ensued after thousands of Palestinians were turned away from returning to their homes in northern Gaza on Sunday, a 5-year-old girl was shot in the head by Israeli soldiers, her mother said.

        Video shows a man carrying a 5-year-old girl named Sally Abu Laila, who was bleeding from her head, with people crowding around her in panic trying to cover her wound.</p>
</body>
</html>
