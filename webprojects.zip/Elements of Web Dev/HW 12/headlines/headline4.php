<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Israeli military official says approximately 350 rockets fired by Iran</title>
</head>
<body>
    <h1>Israeli military official says approximately 350 rockets fired by Iran</h1>
    <p>Israel Defense Forces (IDF) spokesperson Daniel Hagari said that Israel's defensive coalition successfully thwarted the attack from Iran overnight.

        Approximately 350 rockets were fired from Iran, Iraq, Yemen, and Lebanon's Hezbollah, which carried about 60 tonnes of explosives, he said.</p>
</body>
</html>
