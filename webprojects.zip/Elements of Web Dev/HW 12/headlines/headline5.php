<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>US ships destroy missiles headed for Israel, a senior official says</title>
</head>
<body>
    <h1>US ships destroy missiles headed for Israel, a senior official says</h1>
    <p>US ships operating in the eastern Mediterranean Sea engaged in and destroyed between four and six Iranian ballistic missiles during Iran's attack on Israel, according to a senior US military official.

        The official said the aircraft in the region shut down more than 70 Iranian one-way UAVs headed toward Israel. The US Army Patriot missile battery shut down one ballistic missile in the vicinity of Erbil, Iraq, determined to be en route to Israel. </p>
</body>
</html>
