<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Israel is not seeking war after Iran's attack, President Herzog says</title>
</head>
<body>
    <h1>Israel is not seeking war after Iran's attack, President Herzog says</h1>
    <p>Israel is not seeking war after Iran's attack and "balance is needed in this situation," Israeli President Isaac Herzog told CNN's Wolf Blitzer on Sunday.

        Prime Minister Benjamin Netanyahu is speaking with many world leaders and there is "intimate dialogue with allies" in response to Iran's actions, he said.    </p>
</body>
</html>
