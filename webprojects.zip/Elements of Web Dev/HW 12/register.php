<?php
session_set_cookie_params([
    'lifetime' => 120,
    'path' => '/',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $accounts = file('passwd.txt');
    $exists = false;

    foreach ($accounts as $account) {
        list($storedUser) = explode(':', trim($account));
        if ($storedUser === $username) {
            $exists = true;
            break;
        }
    }

    if ($exists) {
        $error = "Username already exists. Choose another.";
    } else {
        file_put_contents('passwd.txt', "$username:$password\n", FILE_APPEND);
        header('Location: login.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h1>Register</h1>
    <?php if (!empty($error)): ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <button type="submit">Register</button>
    </form>
</body>
</html>
