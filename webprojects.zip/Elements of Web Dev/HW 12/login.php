<?php
session_set_cookie_params([
    'lifetime' => 120,
    'path' => '/',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $accounts = file('../passwd.txt');
    $found = false;
    foreach ($accounts as $account) {
        list($storedUser, $storedPass) = explode(':', trim($account));
        if ($storedUser === $username && $storedPass === $password) {
            $_SESSION['userid'] = $username;
            $_SESSION['login_time'] = time(); 
            $found = true;
            break;
        }
    }

    if (!$found) {
        $error = "Login failed. Please try again.";
        // Debugging
        echo "Failed login attempt for username: $username";
    } else {
        header('Location: ' . ($_POST['referrer'] ?? 'hw12.html'));
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <?php if (isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="hidden" name="referrer" value="<?php echo $_SERVER['HTTP_REFERER'] ?? 'hw12.html'; ?>">
        <button type="submit">Login</button>
    </form>
    <p>Or <a href="register.php">register here</a>.</p>
</body>
</html>
