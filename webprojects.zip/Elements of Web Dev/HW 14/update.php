<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $last = $_POST['last'];
    $first = $_POST['first'];
    $major = $_POST['major'];
    $gpa = $_POST['gpa'];

    if (!empty($id) && (!empty($last) || !empty($first) || !empty($major) || !empty($gpa))) {
        $query = "UPDATE students SET ";
        $toUpdate = [];
        $types = "";
        $values = [];

        if (!empty($last)) {
            $toUpdate[] = "last=?";
            $types .= "s";
            $values[] = $last;
        }
        if (!empty($first)) {
            $toUpdate[] = "first=?";
            $types .= "s";
            $values[] = $first;
        }
        if (!empty($major)) {
            $toUpdate[] = "major=?";
            $types .= "s";
            $values[] = $major;
        }
        if (!empty($gpa)) {
            $toUpdate[] = "gpa=?";
            $types .= "d";
            $values[] = $gpa;
        }

        $query .= implode(", ", $toUpdate) . " WHERE id=?";
        $types .= "i";
        $values[] = $id;

        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$values);

        if ($stmt->execute()) {
            $message = "Record updated successfully!";
        } else {
            $message = "Error updating record: " . $conn->error;
        }

        $stmt->close();
    } else {
        $message = "ID and at least one other field are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Student Record</title>
</head>
<body>
    <h2>Update Student Record</h2>
    <p><?php echo $message; ?></p>
    <form method="post">
        ID (required): <input type="number" name="id" required><br>
        Last Name: <input type="text" name="last"><br>
        First Name: <input type="text" name="first"><br>
        Major: <input type="text" name="major"><br>
        GPA: <input type="text" name="gpa" pattern="\d*(\.\d{1,2})?" title="GPA must be a number with up to two decimal places"><br>
        <input type="submit" value="Update Record">
    </form>
    <a href="actions.php">Back to Actions</a>
</body>
</html>
