<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $isValid = false;
    $accounts = file('passwd.txt', FILE_IGNORE_NEW_LINES);
    foreach ($accounts as $account) {
        list($storedUser, $storedPass) = explode(':', $account);
        if ($username === $storedUser && $password === $storedPass) {
            $isValid = true;
            break;
        }
    }

    if ($isValid) {
        $_SESSION['user'] = $username;
        header('Location: actions.php');
        exit();
    } else {
        $message = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Homework 14</title>
</head>
<body>
    <h2>Login</h2>
    <?php if (!empty($message)) echo "<p>$message</p>"; ?>
    <form method="post">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
