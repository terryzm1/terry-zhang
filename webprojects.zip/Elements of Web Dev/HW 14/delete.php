<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    if (!empty($id)) {
        $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $message = "Record deleted successfully!";
        } else {
            $message = "Error deleting record: " . $conn->error;
        }

        $stmt->close();
    } else {
        $message = "ID is required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Student Record</title>
</head>
<body>
    <h2>Delete Student Record</h2>
    <p><?php echo $message; ?></p>
    <form method="post">
        ID: <input type="number" name="id" required><br>
        <input type="submit" value="Delete Record">
    </form>
    <a href="actions.php">Back to Actions</a>
</body>
</html>
