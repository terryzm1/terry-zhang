<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Actions</title>
</head>
<body>
    <h1>Actions</h1>
    <ul>
        <li><a href="insert.php">Insert Student Record</a></li>
        <li><a href="update.php">Update Student Record</a></li>
        <li><a href="delete.php">Delete Student Record</a></li>
        <li><a href="view.php">View Student Record</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
