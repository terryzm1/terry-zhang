<?php
session_start();
echo "<script>alert('Thank you for using the system.');</script>";
session_destroy();
header('Refresh: 1; URL=login.php');
