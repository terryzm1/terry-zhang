<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$message = '';
$results = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $last = $_POST['last'];
    $first = $_POST['first'];

    $query = "SELECT * FROM students";
    $conditions = [];
    $params = [];
    $types = '';

    if (!empty($id)) {
        $conditions[] = "id = ?";
        $params[] = $id;
        $types .= 'i';
    }
    if (!empty($last)) {
        $conditions[] = "last LIKE ?";
        $params[] = "%$last%";
        $types .= 's';
    }
    if (!empty($first)) {
        $conditions[] = "first LIKE ?";
        $params[] = "%$first%";
        $types .= 's';
    }

    if (count($conditions) > 0) {
        $query .= " WHERE " . implode(' AND ', $conditions);
    }

    $query .= " ORDER BY last, first";

    $stmt = $conn->prepare($query);
    if (!empty($types)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
    } else {
        $message = "No matches found.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Student Records</title>
</head>
<body>
    <h2>View Student Records</h2>
    <p><?php echo $message; ?></p>
    <form method="post">
        ID: <input type="text" name="id"><br>
        Last Name: <input type="text" name="last"><br>
        First Name: <input type="text" name="first"><br>
        <input type="submit" value="Search">
    </form>
    <form method="post">
        <input type="submit" name="viewall" value="View All Student Records">
    </form>
    <?php
    if (!empty($results)) {
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Last Name</th><th>First Name</th><th>Major</th><th>GPA</th></tr>";
        foreach ($results as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['last']) . "</td>";
            echo "<td>" . htmlspecialchars($row['first']) . "</td>";
            echo "<td>" . htmlspecialchars($row['major']) . "</td>";
            echo "<td>" . htmlspecialchars($row['gpa']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    ?>
    <a href="actions.php">Back to Actions</a>
</body>
</html>
