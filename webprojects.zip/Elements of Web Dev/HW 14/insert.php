<?php
session_start();
require 'db.php'; 

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $last = $_POST['last'];
    $first = $_POST['first'];
    $major = $_POST['major'];
    $gpa = $_POST['gpa'];

    if (!empty($id) && !empty($last) && !empty($first) && !empty($major) && !empty($gpa)) {

        $stmt = $conn->prepare("INSERT INTO students (id, last, first, major, gpa) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isssd", $id, $last, $first, $major, $gpa);

        if ($stmt->execute()) {
            $message = "Record inserted successfully!";
        } else {
            $message = "Error inserting record: " . $conn->error;
        }

        $stmt->close();
    } else {
        $message = "All fields are required!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insert Student Record</title>
</head>
<body>
    <h2>Insert Student Record</h2>
    <p><?php echo $message; ?></p>
    <form method="post">
        ID: <input type="number" name="id" required><br>
        Last Name: <input type="text" name="last" required><br>
        First Name: <input type="text" name="first" required><br>
        Major: <input type="text" name="major" required><br>
        GPA: <input type="text" name="gpa" required pattern="\d*(\.\d{1,2})?" title="GPA must be a number with up to two decimal places"><br>
        <input type="submit" value="Insert Record">
    </form>
    <a href="actions.php">Back to Actions</a>
</body>
</html>
