<?php
$filePath = 'signup.txt';

$signups = [];
if (file_exists($filePath)) {
    $fileContents = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($fileContents as $line) {
        list($hour, $name) = explode(':', $line, 2);
        $signups[$hour] = $name;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['name'])) {
    foreach ($_POST['name'] as $timeSlot => $name) {
        $name = trim($name);
        if (!empty($name) && !isset($signups[$timeSlot])) {
            $fp = fopen($filePath, 'a');
            if (flock($fp, LOCK_EX)) { 
                fwrite($fp, "$timeSlot:$name\n");
                fflush($fp); 
                flock($fp, LOCK_UN); 
            }
            fclose($fp);
        }
    }

    header("Refresh:0");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Homework 11</title>
    <style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        height: 100vh;
        margin: 0;
    }
    table {
        border-collapse: collapse;
        margin-bottom: 20px; 
    }
    th, td {
        border: 1px solid black;
        padding: 8px;
        text-align: center;
    }
    th {
        background-color: #f2f2f2;
    }
    td:first-child {
        width: 150px; 
    }
    input[type="text"] {
        padding: 5px;
    }
    input[type="submit"] {
        padding: 10px 20px;
        cursor: pointer;
    }
</style>

</head>
<body>
<h3>Signup Sheet</h3>
<form action="" method="post">
    <table border="1">
        <tr>
            <th>Time</th>
            <th>Name</th>
        </tr>
        <?php
        for ($hour = 8; $hour <= 17; $hour++) {
            $displayTime = ($hour <= 12) ? $hour : $hour - 12;
            $displayTime .= ($hour < 12) ? ":00 AM" : ":00 PM";

            echo '<tr>';
            echo "<td>$displayTime</td>";
            if (isset($signups[$hour])) {
                echo "<td>" . htmlspecialchars($signups[$hour]) . "</td>";
            } else {
                echo "<td>
                        <input type='text' name='name[{$hour}]'>
                      </td>";
            }
            echo '</tr>';
        }
        ?>
    </table>
    <input type="submit" value="Submit">
</form>

</body>
</html>
