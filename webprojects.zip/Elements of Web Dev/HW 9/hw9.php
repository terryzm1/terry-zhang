<?php

        $q1 = strtolower($_POST['q1']);
        $q2 = strtolower($_POST['q2']);
        $q3 = isset($_POST['q3']) ? $_POST['q3'] : array();
        $q4 = isset($_POST['q4']) ? $_POST['q4'] : array();
        $q5 = strtolower($_POST['q5']);
        $q6 = strtolower($_POST['q6']);


        $answers = array(
            'q1' => 'false',
            'q2' => 'true',
            'q3' => array('cpu'),
            'q4' => array('network'),
            'q5' => 'http',
            'q6' => 'favicon',
        );
        $grade = 0;

        if ($q1 === $answers['q1']) {
            $grade += 1;
        }
        if ($q2 === $answers['q2']) {
            $grade += 1;
        }


        if (count($q3) === count($answers['q3']) && empty(array_diff($answers['q3'], $q3))) {
            $grade += 1;
        }
        if (count($q4) === count($answers['q4']) && empty(array_diff($answers['q4'], $q4))) {
            $grade += 1;
        }

        if ($q5 === $answers['q5']) {
            $grade += 1;
        }
        if ($q6 === $answers['q6']) {
            $grade += 1;
        }

        $alertMessage = 'Your grade is $grade / 6.';

        echo "<script>alert('$alertMessage');</script>";
        ?>

