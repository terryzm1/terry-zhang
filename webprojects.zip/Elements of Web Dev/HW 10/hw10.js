document.addEventListener('DOMContentLoaded', () => {
    const puzzles = ['puzzle1', 'puzzle2', 'puzzle3'];
    const selectedPuzzle = puzzles[Math.floor(Math.random() * puzzles.length)];
    const piecesContainer = document.getElementById('pieces-container');

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]]; 
        }
    }

    const pieceNumbers = Array.from({length: 12}, (_, i) => i + 1);
    shuffleArray(pieceNumbers); 

    pieceNumbers.forEach((number) => {
        const img = document.createElement('img');
        img.src = `${selectedPuzzle}/img${selectedPuzzle.charAt(selectedPuzzle.length - 1)}-${number}.jpg`;
        img.id = `piece-${number}`;
        img.className = 'puzzle-piece';
        img.draggable = true;
        img.ondragstart = (event) => {
            event.dataTransfer.setData('text/plain', event.target.id);
        };
        piecesContainer.appendChild(img);
    });

    const puzzleContainer = document.getElementById('puzzle-container');
    puzzleContainer.ondragover = (event) => {
        event.preventDefault();
    };

    puzzleContainer.ondrop = (event) => {
        event.preventDefault();
        const id = event.dataTransfer.getData('text');
        const draggableElement = document.getElementById(id);
        const dropzone = event.target;

        if (dropzone.id === 'puzzle-container') {
            puzzleContainer.appendChild(draggableElement);
            draggableElement.style.position = 'absolute';
            draggableElement.style.left = `${event.offsetX - 50}px`;
            draggableElement.style.top = `${event.offsetY - 50}px`;
        }
    };
});
