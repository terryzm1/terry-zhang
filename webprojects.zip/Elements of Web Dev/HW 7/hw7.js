var top_img = 'InteractingGalaxies';
var img_src = ['GalaxyCluster', 'InteractingGalaxies', 'M51', 'M104', 'NGC1300', 'NGC6217'];
var captions = ['Galaxy Cluster', 'Interacting Galaxies', 'M51', 'M104', 'NGC1300', 'NGC6217'];


function get_img () {
    var rnd_idx = Math.floor(Math.random() * img_src.length);
    var temp = [img_src[rnd_idx], captions[rnd_idx]];
    return temp;
 }

function changeImg() {
   var temp = get_img()
   var new_img = temp[0];
   var new_cap = temp[1];
   styleTop = document.getElementById(top_img).style;
   styleNew = document.getElementById(new_img).style;
   
   styleTop.zIndex = "0";
   styleNew.zIndex = "10";

   var captionElement = document.getElementById('caption');
   captionElement.textContent = new_cap;
   
   top_img = new_img;

    


   
   
   
} 

