import UIKit
import CoreBluetooth

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    // Bluetooth properties
    var centralManager: CBCentralManager!
    var arduinoPeripheral: CBPeripheral?
    var arduinoCharacteristic: CBCharacteristic?
    
    // UUIDs for services and characteristics (replace with your module's UUIDs)
    let serviceUUID = CBUUID(string: "12345678-1234-5678-1234-56789abcdef0")
    let characteristicUUID = CBUUID(string: "abcdef01-1234-5678-1234-56789abcdef0")
    
    // UI elements
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var lightLabel: UILabel!
    @IBOutlet weak var moistureLabel: UILabel!
    @IBOutlet weak var pumpSlider: UISlider!
    @IBOutlet weak var sliderValueLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        centralManager = CBCentralManager(delegate: self, queue: nil)
        // Configure slider
        pumpSlider.minimumValue = 150
        pumpSlider.maximumValue = 300
        pumpSlider.value = 150 // Default value
        sliderValueLabel.text = "Pump Duration: \(pumpSlider.value / 60) minutes"
    }
    
    // MARK: - Bluetooth Central Manager Methods
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            centralManager.scanForPeripherals(withServices: [serviceUUID], options: nil)
        } else {
            print("Bluetooth is not available.")
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        print("Discovered peripheral: \(peripheral.name ?? "Unknown")")
        arduinoPeripheral = peripheral
        arduinoPeripheral?.delegate = self
        centralManager.stopScan()
        centralManager.connect(peripheral, options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Connected to \(peripheral.name ?? "Arduino")")
        peripheral.discoverServices([serviceUUID])
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let services = peripheral.services {
            for service in services {
                print("Discovered service: \(service.uuid)")
                peripheral.discoverCharacteristics([characteristicUUID], for: service)
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let characteristics = service.characteristics {
            for characteristic in characteristics {
                if characteristic.uuid == characteristicUUID {
                    print("Discovered characteristic: \(characteristic.uuid)")
                    arduinoCharacteristic = characteristic
                    peripheral.setNotifyValue(true, for: characteristic)
                }
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let data = characteristic.value, let jsonString = String(data: data, encoding: .utf8) {
            updateSensorData(jsonString: jsonString)
        }
    }
    
    // MARK: - Helper Methods
    
    func updateSensorData(jsonString: String) {
        guard let jsonData = jsonString.data(using: .utf8) else { return }
        do {
            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                if let temperature = json["temperature"] as? Double {
                    temperatureLabel.text = "Temperature: \(temperature)°F"
                }
                if let humidity = json["humidity"] as? Double {
                    humidityLabel.text = "Humidity: \(humidity)%"
                }
                if let light = json["light"] as? Int {
                    lightLabel.text = "Light: \(light == 0 ? "Dark" : "Bright")"
                }
                if let moisture = json["soil_moisture"] as? Int {
                    moistureLabel.text = "Moisture: \(moisture)"
                }
            }
        } catch {
            print("Error parsing sensor data: \(error)")
        }
    }
    
    func sendCommand(_ command: String) {
        guard let characteristic = arduinoCharacteristic, let data = command.data(using: .utf8) else { return }
        arduinoPeripheral?.writeValue(data, for: characteristic, type: .withResponse)
    }
    
    // MARK: - Actions
    
    @IBAction func toggleLightSwitch(_ sender: UISwitch) {
        let command = sender.isOn ? "LIGHT_ON" : "LIGHT_OFF"
        sendCommand(command)
        print("Sent command: \(command)")
    }
    
    @IBAction func pumpStartButtonPressed(_ sender: UIButton) {
        let duration = Int(pumpSlider.value)
        let command = "PUMP_START_\(duration)"
        sendCommand(command)
        print("Sent command: \(command)")
    }
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        // Round slider to nearest 5-second increment
        let step: Float = 5
        let roundedValue = round(sender.value / step) * step
        sender.value = roundedValue
        
        // Update the slider value label
        sliderValueLabel.text = "Pump Duration: \(Int(roundedValue)/60) mins"
    }
}
