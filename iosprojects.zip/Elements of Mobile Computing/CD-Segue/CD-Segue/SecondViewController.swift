//
//  SecondViewController.swift
//  CD-Segue
//
//  Created by bulko on 9/18/24.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var nameLabel2: UILabel!
    @IBOutlet weak var textField2: UITextField!
    
    var vc2NewName = ""
    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel2.text = vc2NewName
    }

    @IBAction func button2Pressed(_ sender: Any) {
        
        let otherVC = delegate as! TextChanger
        otherVC.changeText(newName: textField2.text!)
        //self.dismiss(animated:true)
        
    }
    
}
