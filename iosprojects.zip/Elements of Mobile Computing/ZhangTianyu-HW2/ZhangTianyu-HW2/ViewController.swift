// Project: ZhangTianyu-HW2
// EID: tz4453
// Course: CS329E

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userID: UITextField!
    @IBOutlet weak var statusField: UILabel!
    @IBOutlet weak var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        userID.delegate = self
        password.delegate = self
    }
    
    func textFieldShouldReturn(_ textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBAction func login(_ sender: Any) {

        if let userID = userID.text, let password = password.text {
            if userID.isEmpty || password.isEmpty {
                statusField.text = "Invalid login"
            } else {
                statusField.text = "\(userID) logged in"
            }
        } else {

            statusField.text = "Invalid login"
        }
    }
    
    
}

