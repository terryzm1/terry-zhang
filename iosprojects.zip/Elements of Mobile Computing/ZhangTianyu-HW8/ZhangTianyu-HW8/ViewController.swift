// Project: ZhangTianyu-HW8
// EID: tz4453
// Course: CS329E

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageButton: UIButton!
    
    let imageCount = 2
    var current = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showImage(index: current)
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, error in
            if let error = error {
                print("Notification permission error: \(error)")
            }
        }
    }
    
    func showImage(index: Int) {
        imageButton.setImage(UIImage(named: "image\(index)"), for: .normal)    }
    

    @IBAction func buttonPressed(_ sender: Any) {
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {
            self.imageButton.alpha = 0.0
        }) { _ in

            self.current += 1
            self.showImage(index: self.current % self.imageCount)

            UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseIn, animations: {
                self.imageButton.alpha = 1.0
            }, completion: nil)
            
            if self.current == 4 {
                self.scheduleNotification()
            }
        }

    }
    func scheduleNotification() {
           
            let content = UNMutableNotificationContent()
            content.title = "Click Count"
            content.subtitle = "Click notification"
            content.body = "You have clicked 4 times"
            
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 8, repeats: false)
            
            let request = UNNotificationRequest(identifier: "ClickCountNotification", content: content, trigger: trigger)
            
            UNUserNotificationCenter.current().add(request) { error in
                if let error = error {
                    print("Failed to schedule notification: \(error)")
                } else {
                    print("Notification scheduled successfully")
                }
            }
        }
    
}

