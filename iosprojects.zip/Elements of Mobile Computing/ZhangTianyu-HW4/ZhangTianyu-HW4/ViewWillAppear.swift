// Project: ZhangTianyu-HW4
// EID: tz4453
// Course: CS329E
import UIKit

class ViewWillAppear: UIViewController {

    @IBOutlet weak var op1: UILabel!
    @IBOutlet weak var op2: UILabel!
    @IBOutlet weak var operatorText: UILabel!
    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var result: UILabel!
    
    var opName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if opName == "Add" {
            operatorText.text = "+"
        }
        else if opName == "Subtract" {
            operatorText.text = "-"
        }
        else if opName == "Multiply" {
            operatorText.text = "*"
        }
        else if opName == "Divide" {
            operatorText.text = "/"
        }
        
        
    }
    

    @IBAction func calculate(_ sender: Any) {
        if opName == "Add" {
            guard let a = Float(textField1.text!) else {
                return
            }
            guard let b = Float(textField2.text!) else {
                return
            }
            let c = a + b
            let cText = String(c)
            result.text = cText
            
        }
        else if opName == "Subtract" {
            guard let a = Float(textField1.text!) else {
                return
            }
            guard let b = Float(textField2.text!) else {
                return
            }
            let c = a - b
            let cText = String(c)
            result.text = cText
        }
        else if opName == "Multiply" {
            guard let a = Float(textField1.text!) else {
                return
            }
            guard let b = Float(textField2.text!) else {
                return
            }
            let c = a * b
            let cText = String(c)
            result.text = cText
        }
        else if opName == "Divide" {
            guard let a = Float(textField1.text!) else {
                return
            }
            guard let b = Float(textField2.text!) else {
                return
            }
            let c = a / b
            let cText = String(c)
            result.text = cText
        }
        
    }
    

}
