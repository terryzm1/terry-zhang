// Project: ZhangTianyu-HW9
// EID: tz4453
// Course: CS329E

import UIKit

class ViewController: UIViewController {
    
    var blockView: UIView!
    var timer: Timer?
    
    let gridColumns = 9
    let gridRows = 19
    var blockDirection: CGPoint = CGPoint(x: 0, y: 0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeBlock()
        addGestureRecognizers()
    }
    
    func initializeBlock() {

        let blockWidth = view.bounds.width / CGFloat(gridColumns)
        let blockHeight = view.bounds.height / CGFloat(gridRows)
        
        blockView = UIView(frame: CGRect(x: 0, y: 0, width: blockWidth, height: blockHeight))
        blockView.backgroundColor = .green
        view.addSubview(blockView)
        centerBlock()
    }
    
    func addGestureRecognizers() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTapGesture))
        view.addGestureRecognizer(tapGesture)
        
        let directions: [UISwipeGestureRecognizer.Direction] = [.up, .down, .left, .right]
        for direction in directions {
            let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipeGesture(_:)))
            swipeGesture.direction = direction
            view.addGestureRecognizer(swipeGesture)
        }
    }
    
    @objc func handleTapGesture() {
        centerBlock()
        blockView.backgroundColor = .green
        
        blockDirection = CGPoint(x: 0, y: 1)
        startMovingBlock()
    }
    
    @objc func handleSwipeGesture(_ gesture: UISwipeGestureRecognizer) {
        guard timer != nil else { return }
        
        switch gesture.direction {
        case .up:
            blockDirection = CGPoint(x: 0, y: -1)
        case .down:
            blockDirection = CGPoint(x: 0, y: 1)
        case .left:
            blockDirection = CGPoint(x: -1, y: 0)
        case .right:
            blockDirection = CGPoint(x: 1, y: 0)
        default:
            break
        }
    }
    
    func startMovingBlock() {
        timer?.invalidate()
        
        timer = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(moveBlock), userInfo: nil, repeats: true)
    }
    
    @objc func moveBlock() {
        let blockWidth = view.bounds.width / CGFloat(gridColumns)
        let blockHeight = view.bounds.height / CGFloat(gridRows)
        
        let newX = blockView.frame.origin.x + blockDirection.x * blockWidth
        let newY = blockView.frame.origin.y + blockDirection.y * blockHeight
        
        if newX < 0 || newX >= view.bounds.width || newY < 0 || newY >= view.bounds.height {
            timer?.invalidate()
            blockView.backgroundColor = .red
            return
        }
        
        blockView.frame.origin = CGPoint(x: newX, y: newY)
    }
    
    func centerBlock() {
        let blockWidth = view.bounds.width / CGFloat(gridColumns)
        let blockHeight = view.bounds.height / CGFloat(gridRows)
        
        let centerX = (view.bounds.width - blockWidth) / 2
        let centerY = (view.bounds.height - blockHeight) / 2
        blockView.frame.origin = CGPoint(x: centerX, y: centerY)
    }
}
