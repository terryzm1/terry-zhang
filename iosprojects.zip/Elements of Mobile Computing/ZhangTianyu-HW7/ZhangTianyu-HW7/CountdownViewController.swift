// Project: ZhangTianyu-HW7
// EID: tz4453
// Course: CS329E


import UIKit

class CountdownViewController: UIViewController {
    
    var uniqueEvent: String = ""
    var uniqueLocation: String = ""
    var uniqueTime: Int = 0
    var delegate: UIViewController!

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var locLabel: UILabel!
    @IBOutlet weak var eventLabel: UILabel!
    
    private var countdownThread: Thread?
    private var shouldStopCountdown = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        eventLabel.text = uniqueEvent
        locLabel.text = uniqueLocation
        timeLabel.text = String(uniqueTime)
        startCountdown()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        shouldStopCountdown = true
        countdownThread?.cancel()
        
        // Pass the remaining time back to the main VC
        if let mainVC = navigationController?.viewControllers.first as? ViewController {
            mainVC.updateEventTime(for: uniqueEvent, with: uniqueTime)
        }
    }

    
    func startCountdown() {
        shouldStopCountdown = false
        countdownThread = Thread {
            while self.uniqueTime > 0 && !self.shouldStopCountdown {
                Thread.sleep(forTimeInterval: 1.0) // Sleep for 1 second
                self.uniqueTime -= 1 // Decrease the countdown
                
                // Update the label on the main thread
                DispatchQueue.main.async {
                    self.timeLabel.text = String(self.uniqueTime)
                }
                
                // Stop if time reaches zero
                if self.uniqueTime <= 0 {
                    break
                }
            }
        }
        countdownThread?.start()
    }



}
