// Project: ZhangTianyu-HW7
// EID: tz4453
// Course: CS329E


import UIKit

protocol TimerAdder {
    func addTimer(timerObj: Timer)
}

public class Timer {
    
    var event: String
    var location: String
    var time: String
    
    init(event: String, location: String, time: String) {
        self.event = event
        self.location = location
        self.time = time
    }
}

var timers: [Timer] = []

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TimerAdder {
    
    func addTimer(timerObj: Timer) {
        timers.append(timerObj)
        tableView.reloadData()
    }
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimerCell", for: indexPath) as! TimerTableViewCell
        let row = timers[indexPath.row]
        cell.textLabel?.numberOfLines = 0
        cell.eventLabel.text = "Event " + String(row.event)
        cell.locationLabel.text = "Location " + String(row.location)
        cell.timeRemainingLabel.text = "Remaining Time (s) " + String(row.time)
        return cell
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toAddTimer",
           let nextVC = segue.destination as? AddTimerViewController {
            nextVC.delegate = self

        }
        if segue.identifier == "toCountdown",
           let nextVC = segue.destination as? CountdownViewController,
           let indexPath = tableView.indexPathForSelectedRow {
            nextVC.delegate = self
            let selectedTimer = timers[indexPath.row]
            nextVC.uniqueEvent = selectedTimer.event
            nextVC.uniqueLocation = selectedTimer.location
            nextVC.uniqueTime = Int(selectedTimer.time)!
            
        }
    }
    
    func updateEventTime(for event: String?, with timeInSeconds: Int) {
        guard let eventName = event else { return }
        
        if let index = timers.firstIndex(where: { $0.event == eventName }) {
            timers[index].time = String(timeInSeconds)
            let indexPath = IndexPath(row: index, section: 0)
            tableView.reloadRows(at: [indexPath], with: .none)
        }
    }
    
}

