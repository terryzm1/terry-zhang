// Project: ZhangTianyu-HW7
// EID: tz4453
// Course: CS329E

import UIKit

class AddTimerViewController: UIViewController {
    
    var delegate: UIViewController!

    @IBOutlet weak var eventField: UITextField!
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var timeField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        let newEv = eventField.text!
        let newLoc = locationField.text!
        let newTime = timeField.text!
        let newTimer = Timer(event: newEv, location: newLoc, time: newTime)
        let homeVC = delegate as! TimerAdder
        homeVC.addTimer(timerObj: newTimer)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
