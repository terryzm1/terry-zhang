//
//  ZhangTianyu_HW10App.swift
//  ZhangTianyu-HW10
//
//  Created by Terry Zhang on 12/4/24.
//

import SwiftUI

@main
struct ZhangTianyu_HW10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
