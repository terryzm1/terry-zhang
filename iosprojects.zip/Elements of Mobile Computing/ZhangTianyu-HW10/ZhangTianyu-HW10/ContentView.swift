//
//  ContentView.swift
//  ZhangTianyu-HW10
//
//  Created by Terry Zhang on 12/4/24.
//

import SwiftUI

struct ContentView: View {
    @State private var userID: String = ""
    @State private var password: String = ""
    @State private var statusMessage: String = "Not currently logged in"
    
    var body: some View {
        VStack(spacing: 25) {

            Text("User Login")
                .font(.headline)
                .padding(.top, 25)

            HStack {
                Text("userID:")
                    .frame(width: 80, alignment: .trailing)
                TextField("", text: $userID)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 20)
            

            HStack {
                Text("Password:")
                    .frame(width: 80, alignment: .trailing)
                TextField("", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 20)
            

            Button("Login") {
                handleLogin()
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .foregroundColor(.blue)
            .cornerRadius(5)
            .padding(.horizontal, 20)
            
            Text(statusMessage)
                .padding(.top, 20)
            
            Spacer()
        }
        .background(Color(UIColor.systemBackground))
        .onTapGesture {
            hideKeyboard()
        }
    }
    

    private func handleLogin() {
        if userID.isEmpty || password.isEmpty {
            statusMessage = "Invalid login"
        } else {
            statusMessage = "\(userID) logged in"
        }
    }
}

extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

#Preview {
    ContentView()
}
