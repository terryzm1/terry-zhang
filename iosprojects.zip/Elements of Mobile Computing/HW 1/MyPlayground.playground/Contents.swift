// Project: ZhangTianyu-HW1
// EID: tz4453
// Course: CS329E

class Weapon {
    var weaponType: String
    var damage: Int
    
    init(weaponType: String) {
        self.weaponType = weaponType
        if self.weaponType == "dagger" {
            self.damage = 4
        }
        else if (self.weaponType == "axe" || self.weaponType == "staff") {
            self.damage = 6
        }
        else if self.weaponType == "sword" {
            self.damage = 10
        }
        else {
            self.damage = 1
        }
    }
    
}

class Armor {
    var armorType: String
    var AC: Int
    
    init(armorType: String) {
        self.armorType = armorType
        if self.armorType == "plate" {
            self.AC = 2
        }
        else if self.armorType == "chain" {
            self.AC = 5
        }
        else if self.armorType == "leather" {
            self.AC = 8
        }
        else {
            self.AC = 10
        }
    }
}

class RPGCharacter{
    var name: String
    var maxHealth = 0
    var health = 0
    var spellPoints = 0
    var weapon = Weapon(weaponType: "none")
    var armor = Armor(armorType: "none")
    
    init(name: String) {
        self.name = name
    }
    
    func wield(weapon: Weapon) {
        self.weapon = weapon
        print("\(self.name) is now wielding a(n) \(self.weapon.weaponType)")
    }
    
    func unwield() {
        self.weapon = Weapon(weaponType: "none")
        print("\(self.name) is no longer wielding anything.")
    }
    
    func putOnArmor(armor: Armor) {
        self.armor = armor
        print("\(self.name) is now wearing \(self.armor.armorType)")
    }
    
    func takeOffArmor() {
        self.armor = Armor(armorType: "none")
        print("\(self.name) is no longer wearing any armor")
    }
    
    func fight(opp: RPGCharacter) {
        print("\(self.name) attacks \(opp.name) with a(n) \(self.weapon.weaponType)")
        opp.health -= self.weapon.damage
        print("\(self.name) does \(self.weapon.damage) damage to \(opp.name)")
        print("\(opp.name) is now down to \(opp.health) health")
        checkForDefeat(opp)
    }
    
    func show() {
        print("\(self.name)\n\tCurrent Health: \(self.health)\n\tCurrentSpellPoints: \(self.spellPoints)\n\tWielding: \(self.weapon.weaponType)\n\tWearing: \(self.armor.armorType)\n\tArmor Class: \(self.armor.AC)")
    }
    
}

class Fighter: RPGCharacter {
    override init(name: String) {
        super.init(name: name)
        self.maxHealth = 40
        self.health = 40
        self.spellPoints = 0
    }
    
}

class Wizard: RPGCharacter {
    override init(name: String) {
        super.init(name: name)
        self.maxHealth = 16
        self.health = 16
        self.spellPoints = 20
    }
    
    override func wield(weapon: Weapon) {
        if (weapon.weaponType == "dagger") || (weapon.weaponType == "staff") {
            self.weapon = weapon
            print("\(self.name) is now wielding a(n) \(self.weapon.weaponType)")
        }
        else {
            print("Weapon not allowed for this character class.")
        }
    }
    
    override func putOnArmor(armor: Armor) {
        print("Armor not allowed for this character class.")
    }
    
    func castSpell(spell: String, opp: RPGCharacter) {
        var cost: Int
        var effect: Int
        
        if spell == "Fireball" {
            cost = 3
            effect = 5
        }
        else if spell == "Lightning Bolt" {
            cost = 10
            effect = 10
        }
        else if spell == "Heal" {
            cost = 6
            effect = -6
        }
        else {
            print("Unknown spell name. Spell failed.")
            return
        }
        
        if self.spellPoints < cost {
            print("Insufficient spell points")
            return
        }
        self.spellPoints -= cost
        
        print("\(self.name) casts \(spell) at \(opp.name)")
        if opp.health - effect <= opp.maxHealth {
            opp.health -= effect
        }
        
        if spell == "Heal" {
            print("\(self.name) heals \(opp.name) for 6 health points")
            print("\(opp.name) is now at \(opp.health)")
            return
        }
        
        print("\(self.name) does \(effect) damage to \(opp.name)")
        print("\(opp.name) is now down to \(opp.health) health")
        checkForDefeat(opp)
    }
}

func checkForDefeat(_ player: RPGCharacter) {
    if player.health <= 0 {
        print("\(player.name) has been defeated!")
    }
}


// top level code
let plateMail = Armor(armorType: "plate")
let chainMail = Armor(armorType: "chain")
let sword = Weapon(weaponType: "sword")
let staff = Weapon(weaponType: "staff")
let axe = Weapon(weaponType: "axe")
let gandalf = Wizard(name: "Gandalf the Grey")
gandalf.wield(weapon: staff)
let aragorn = Fighter(name: "Aragorn")
aragorn.putOnArmor(armor: plateMail)
aragorn.wield(weapon: axe)
gandalf.show()
aragorn.show()
gandalf.castSpell(spell: "Fireball", opp: aragorn)
aragorn.fight(opp: gandalf)
gandalf.show()
aragorn.show()
gandalf.castSpell(spell: "Lightning Bolt", opp: aragorn)
aragorn.wield(weapon: sword)
gandalf.show()
aragorn.show()
gandalf.castSpell(spell: "Heal", opp: gandalf)
aragorn.fight(opp: gandalf)
gandalf.fight(opp: aragorn)
aragorn.fight(opp: gandalf)
gandalf.show()
aragorn.show()
