// Project: ZhangTianyu-HW3
// EID: tz4453
// Course: CS329E

import UIKit

protocol TextChanger {
    func changeText(newText: String)
        
}

protocol ColorChanger {
    func changeColor(color: String)
}

class ViewController: UIViewController, TextChanger, ColorChanger {


    

    @IBOutlet weak var label1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if segue.identifier == "TextChangeSegue",
           let nextVC = segue.destination as? TextChange {
            nextVC.delegate = self
            nextVC.vc2NewName = label1.text!
        }
        if segue.identifier == "ColorChangeSegue",
           let nextVC = segue.destination as? ColorChange {
            nextVC.delegate = self
        }
    }
    func changeText(newText: String) {
        label1.text = newText
    }
    
    func changeColor(color: String) {
        if color == "blue"{
            label1.backgroundColor = UIColor.blue
        }
        else {
            label1.backgroundColor = UIColor.red
        }
    }
    
   
}

