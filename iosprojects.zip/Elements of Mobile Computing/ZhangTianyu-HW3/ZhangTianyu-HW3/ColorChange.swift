// Project: ZhangTianyu-HW3
// EID: tz4453
// Course: CS329E

import UIKit

class ColorChange: UIViewController {

    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func blueButton(_ sender: Any) {
        let mainVC = delegate as? ColorChanger
        mainVC?.changeColor(color: "blue")
    }
    
    @IBAction func redButton(_ sender: Any) {
        let mainVC = delegate as? ColorChanger
        mainVC?.changeColor(color: "red")
    }
}
