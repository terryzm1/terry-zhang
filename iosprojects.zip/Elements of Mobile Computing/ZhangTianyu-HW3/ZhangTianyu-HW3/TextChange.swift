// Project: ZhangTianyu-HW3
// EID: tz4453
// Course: CS329E

import UIKit

class TextChange: UIViewController {

    @IBOutlet weak var textField1: UITextField!
    
    var delegate: UIViewController!
    var vc2NewName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField1.text = vc2NewName
        // Do any additional setup after loading the view.
    }
    

    @IBAction func button1(_ sender: Any) {
        let mainVC = delegate as? TextChanger
        mainVC?.changeText(newText: textField1.text!)
    }
    

}
