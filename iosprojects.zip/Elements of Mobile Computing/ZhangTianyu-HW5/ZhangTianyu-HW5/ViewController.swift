// Project: ZhangTianyu-HW5
// EID: tz4453
// Course: CS329E

import UIKit
import FirebaseAuth
import CoreData



protocol PizzaAdder {
    func addPizza(pizza:Pizza)
}

class Pizza {
    var pSize: String
    var crust: String
    var cheese: String
    var meat: String
    var veggies: String
    
    
    
    init(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        self.pSize = pSize
        self.crust = crust
        self.cheese = cheese
        self.meat = meat
        self.veggies = veggies
    }
    
    var description: String {
        return "\(self.pSize)\n\t\(self.crust) \n\t\(self.cheese)\n\t\(self.meat)\n\t\(self.veggies)"
    }
}

var pizzaList:[Pizza] = []

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, PizzaAdder {
    func addPizza(pizza: Pizza) {
        pizzaList.append(pizza)
        pizzaTable.reloadData()
        print(pizza.description)
    }
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    
    

    @IBOutlet weak var pizzaTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pizzaTable.dataSource = self
        pizzaTable.delegate = self

        let backButton = UIBarButtonItem()
        backButton.title = "Pizza Order"
        navigationItem.backBarButtonItem = backButton
        
        if Auth.auth().currentUser == nil {
            // If no user is logged in, redirect to login screen
            self.performSegue(withIdentifier: "toLogin", sender: self)
        }

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        retrievePizza()
        pizzaTable.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toPizzaCreationVC",
           let nextVC = segue.destination as? PizzaViewController {
            nextVC.delegate = self

        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count // number of pizzas in your list
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PizzaCell", for: indexPath)
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = pizzaList[indexPath.row].description // customize this for pizza description
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            pizzaList.remove(at: indexPath.row)
            
            
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.reloadData()
        }
    }
    
    func retrievePizza() -> [NSManagedObject] {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UniquePizza")
        var fetchedResults: [NSManagedObject]?
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            print("Error while retrieving data")
            abort()
        }
        
        return fetchedResults!
    }
    
    @IBAction func logOut(_ sender: Any) {
        do {
               try Auth.auth().signOut()
               // After signing out, present the login view controller
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
                loginVC.modalPresentationStyle = .fullScreen
                present(loginVC, animated: true, completion: nil)
            }

           } catch let signOutError as NSError {
               print("Error signing out: %@", signOutError)
           }
    }

    //    @IBAction func addPizza(_ sender: Any) {
//        performSegue(withIdentifier: "toPizzaCreationVC", sender: self)
//        
//    }
    


}

