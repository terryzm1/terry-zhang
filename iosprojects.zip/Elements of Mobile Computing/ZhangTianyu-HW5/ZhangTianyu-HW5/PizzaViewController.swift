// Project: ZhangTianyu-HW5
// EID: tz4453
// Course: CS329E

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

class PizzaViewController: UIViewController {
    
    var selectedCrust: String?
    var selectedCheese: String?
    var selectedSize: String = "Small"
    var selectedMeat: String?
    var selectedVeggies: String?


    @IBOutlet weak var sizeSegmentedControl: UISegmentedControl!
    

    @IBOutlet weak var pizzaSummaryLabel1: UILabel!

    
    var delegate: UIViewController!
    var newPizza: Pizza?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pizzaSummaryLabel1.text = ""

        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
     
    */
    
    @IBAction func selectCrust(_ sender: Any) {
        let alert = UIAlertController(title: "Choose Crust", message: "Choose a crust type", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Thin Crust", style: .default, handler: { (_) in
            self.selectedCrust = "Thin Crust"
        }))
        alert.addAction(UIAlertAction(title: "Thick Crust", style: .default, handler: { (_) in
            self.selectedCrust = "Thick Crust"
        }))
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func selectCheese(_ sender: Any) {
        let cheeseActionSheet = UIAlertController(title: "Choose Cheese", message: "Choose a cheese type", preferredStyle: .actionSheet)
        cheeseActionSheet.addAction(UIAlertAction(title: "Regular Cheese", style: .default, handler: { _ in
            self.selectedCheese = "Regular Cheese"

        }))
        cheeseActionSheet.addAction(UIAlertAction(title: "No Cheese", style: .default, handler: { _ in
            self.selectedCheese = "No Cheese"
        }))
        cheeseActionSheet.addAction(UIAlertAction(title: "Double Cheese", style: .default, handler: { _ in
            self.selectedCheese = "Double Cheese"
        }))
        present(cheeseActionSheet, animated: true, completion: nil)
    }
    @IBAction func selectMeat(_ sender: Any) {
        let meatActionSheet = UIAlertController(title: "Choose Meat", message: "Choose one meat", preferredStyle: .actionSheet)
        meatActionSheet.addAction(UIAlertAction(title: "Pepperoni", style: .default, handler: { _ in
            self.selectedMeat = "Pepperoni"
            
        }))
        meatActionSheet.addAction(UIAlertAction(title: "Sausage", style: .default, handler: { _ in
            self.selectedMeat = "Sausage"
        }))
        meatActionSheet.addAction(UIAlertAction(title: "Canadian Bacon", style: .default, handler: { _ in
            self.selectedMeat = "Canadian Bacon"
        }))
        present(meatActionSheet, animated: true, completion: nil)
    }
    @IBAction func selectVeggies(_ sender: Any) {
        let vegActionSheet = UIAlertController(title: "Choose veggies", message: "Choose your veggies", preferredStyle: .actionSheet)
        vegActionSheet.addAction(UIAlertAction(title: "Mushroom", style: .default, handler: { _ in
            self.selectedVeggies = "Mushroom"
     
        }))
        vegActionSheet.addAction(UIAlertAction(title: "Onion", style: .default, handler: { _ in
            self.selectedVeggies = "Onion"
        }))
        vegActionSheet.addAction(UIAlertAction(title: "Green Olive", style: .default, handler: { _ in
            self.selectedVeggies = "Green Olive"
        }))
        vegActionSheet.addAction(UIAlertAction(title: "Black Olive", style: .default, handler: { _ in
            self.selectedVeggies = "Black Olive"
        }))
        present(vegActionSheet, animated: true, completion: nil)
    }
    
    @IBAction func doneCreatingPizza(_ sender: Any) {
        if self.selectedCrust == nil || self.selectedCheese == nil || self.selectedMeat == nil || self.selectedVeggies == nil {
            let alert = UIAlertController(title: "Incomplete Order", message: "Please make a selection for all options.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            return
        }
        
        self.selectedSize = sizeSegmentedControl.titleForSegment(at: sizeSegmentedControl.selectedSegmentIndex)!
        
        pizzaSummaryLabel1.numberOfLines = 0

        pizzaSummaryLabel1.text = "One \(self.selectedSize) pizza with: \r\t\(self.selectedCrust!) \r\t\(self.selectedCheese!)\r\t\(self.selectedMeat!)\r\t\(self.selectedVeggies!)"
        
        var newPiz = Pizza(pSize: self.selectedSize, crust: self.selectedCrust!, cheese: self.selectedCheese!, meat: self.selectedMeat!, veggies: self.selectedVeggies!)
        
        
        let otherVC = delegate as! PizzaAdder
        otherVC.addPizza(pizza: newPiz)
        storePizza(pizza: newPiz)
        //self.dismiss(animated: false)
        
    }
    func storePizza(pizza:Pizza) {
        let newPizza = NSEntityDescription.insertNewObject(forEntityName: "UniquePizza", into: context)
        
        newPizza.setValue(pizza.pSize, forKey: "size")
        newPizza.setValue(pizza.crust, forKey: "crust")
        newPizza.setValue(pizza.cheese, forKey: "cheese")
        newPizza.setValue(pizza.meat, forKey: "meat")
        newPizza.setValue(pizza.veggies, forKey: "veggies")
        
        saveContext()
    }
    
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
               
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    

    

}
