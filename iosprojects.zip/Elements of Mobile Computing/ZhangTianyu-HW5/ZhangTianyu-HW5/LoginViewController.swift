//
//  LoginViewController.swift
//  ZhangTianyu-HW5
//
//  Created by Terry Zhang on 10/23/24.
//

import UIKit
import FirebaseAuth


class LoginViewController: UIViewController {



    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var confirmPassLabel: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var confirmPassTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        status.text = ""
        confirmPassLabel.isHidden = true
        confirmPassTextField.isHidden = true
        submit.setTitle("Log in", for: .normal)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func switchViews(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            confirmPassLabel.isHidden = true
            confirmPassTextField.isHidden = true
            submit.setTitle("Log in", for: .normal)
        }
        else {
            confirmPassLabel.isHidden = false
            confirmPassTextField.isHidden = false
            submit.setTitle("Sign up", for: .normal)
        }
    }
    
    @IBAction func buttonClicked(_ sender: Any) {

        guard let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            self.status.text = "One or more fields empty. Try again."
            return
        }

        if segmentedControl.selectedSegmentIndex == 0 {
            
            // Login
            Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
                if let error = error {
                    self.status.text = "Error logging in"
                    // Show an alert for login error
                } else {
                    print("User logged in: \(authResult?.user.email ?? "")")
                    self.performSegue(withIdentifier: "toMainView", sender: self)
                    // Navigate to the main screen or update UI for login success
                }
            }
        } else {
            guard let confirmPass = confirmPassTextField.text, !confirmPass.isEmpty, confirmPass == password else {
                self.status.text = "Passwords do not match. Try again."
                return
            }
            // Sign Up
            Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                if let error = error {
                    self.status.text = "Error signing up"
                    // Show an alert for sign-up error
                } else {
                    print("User signed up: \(authResult?.user.email ?? "")")
                    self.performSegue(withIdentifier: "toMainView", sender: self)
                    // Navigate to the main screen or update UI for sign-up success
                }
            }
        }
    }
}
